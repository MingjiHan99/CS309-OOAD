package original.bean;

public class Computer {
    private int id;
    private String name;

    public Computer(int staffID){

    }
}
